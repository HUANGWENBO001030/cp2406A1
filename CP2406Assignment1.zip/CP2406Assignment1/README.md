# CP2406Assignment

Assignment 1 for CP2406

WenBo Huang A1 Programming 3
